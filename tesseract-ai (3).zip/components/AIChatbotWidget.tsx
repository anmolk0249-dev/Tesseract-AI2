import { useState } from "react";
import { motion } from "framer-motion";

export default function AIChatbotWidget() {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "👋 Hi, I'm Vinit, builder of Tesseract AI. Just so you know, I'm here to help with anything you need—whether that's finding a product or answering questions." }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;

    const newMessages = [...messages, { role: "user", content: input }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: newMessages }),
    });

    const data = await res.json();
    const reply = data?.choices?.[0]?.message?.content || "⚠️ Sorry, no response.";

    setMessages([...newMessages, { role: "assistant", content: reply }]);
    setLoading(false);
  };

  return (
    <motion.div
      className="w-[400px] h-[600px] bg-white shadow-2xl rounded-2xl flex flex-col p-4"
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <header className="text-2xl font-extrabold text-center text-purple-700 mb-4 animate-pulse">
        🚀 Tesseract AI
      </header>

      <div className="flex-1 overflow-y-auto border rounded p-2 mb-2 bg-gray-50">
        {messages.map((m, i) => (
          <div key={i} className={`mb-2 ${m.role === "user" ? "text-right" : "text-left"}`}>
            <span
              className={`inline-block px-3 py-2 rounded-xl ${
                m.role === "user" ? "bg-purple-500 text-white" : "bg-gray-200 text-black"
              }`}
            >
              {m.content}
            </span>
          </div>
        ))}
        {loading && <p className="text-gray-400">⏳ Thinking...</p>}
      </div>

      <div className="flex gap-2">
        <input
          className="flex-1 border rounded-xl p-2"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message..."
        />
        <button
          className="px-4 py-2 bg-purple-600 text-white rounded-xl hover:bg-purple-700"
          onClick={sendMessage}
        >
          Send
        </button>
      </div>
    </motion.div>
  );
}
